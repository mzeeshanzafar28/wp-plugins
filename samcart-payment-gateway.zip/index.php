<?php
echo "cheatin huh?";