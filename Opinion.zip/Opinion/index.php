<?php
echo "Silence is Golden";