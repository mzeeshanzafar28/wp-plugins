<?php
echo "Settings will be interesting";