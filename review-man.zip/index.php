<?php

echo "No Place for script kiddies in my site.";