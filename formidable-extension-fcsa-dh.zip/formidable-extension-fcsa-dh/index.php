<?php
die('Unauthorized Access');