<?php
echo "You are not allowed to call this page directly";