<?php
echo 'cheatin huh?';