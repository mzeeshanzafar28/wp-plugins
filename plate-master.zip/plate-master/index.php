<?php
echo "No Script Kiddies Please!";