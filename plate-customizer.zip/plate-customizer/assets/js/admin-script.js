jQuery(document).ready(function ($) {

    $('#plate-customizer-plate-price-set').on('input',function(){
        prc = parseFloat($(this).val());
        $('#plate-customizer-front-plate-price-set').val(prc/2);
        $('#plate-customizer-rear-plate-price-set').val(prc/2);

    });

    $('.wp-list-table').on('click', '.drop-this', function () {
        var table = $(this).closest('table');
        var categoryTitle = table.prevAll().find('.category-title').last();
        var property = categoryTitle.text().trim().toLowerCase().replace(/\s+/g, '_');
        var value = $(this).closest('tr').find('td:first-child').text();
        // alert(property + ' : ' + value)
        removePropertyValue(property, value);
        $(this).closest('tr').remove();
    });


    $('.wp-list-table').on('click', '.edit-this', function () {
        var table = $(this).closest('table');
        var categoryTitle = table.prevAll().find('.category-title').last();
        // var property = categoryTitle.text().trim().toLowerCase().replace(/\s+/g, '_');
        var value = $(this).closest('tr').find('td:first-child').text().toLowerCase().replace(/\s+/g, '_');
        const data = {
            action: 'fetch_data_for_plate',
            plate_name: value,
        };
        jQuery.post(plate_customizer_ajax.ajax_url, data, function (response) {
            response = response.slice(0, -1);
            response = JSON.parse(response);
            plate_style = response[0];
            plate_style_price = response[1];
            plate_style_images_array = response[2];
            plate_style_fonts = response[3];
            plate_style_border = response[4];
            plate_style_bottom_text_color = response[5];
            plate_style_bottom_text_font = response[6];
            plate_style_bottom_text_size = response[7];
            plate_style_badge_type = response[8];
            plate_style_badge_images = response[9];
            plate_style_front_plate_price = response[10];
            plate_style_rear_plate_price = response[11];

                $('#plate-customizer-plate-style').val(plate_style);
                $('#plate-customizer-old-name').val(plate_style);
                $('#plate-customizer-plate-price-set').val(plate_style_price);
                $('#plate-customizer-front-plate-price-set').val(plate_style_front_plate_price);
                $('#plate-customizer-rear-plate-price-set').val(plate_style_rear_plate_price);

                function selectOptionsInSelect2(selectId, optionsToSelect) {
                    $(selectId).val(null).trigger('change');
                
                    optionsToSelect.forEach(function(option) {
                        $(selectId).append('<option value="' + option + '" selected="selected">' + option + '</option>');
                    });
                
                    $(selectId).trigger('change');
                }
                
                selectOptionsInSelect2('.plate_style_fonts', plate_style_fonts);
                selectOptionsInSelect2('.plate_style_badge_type', plate_style_badge_type);
                selectOptionsInSelect2('.plate_style_border', plate_style_border);
                selectOptionsInSelect2('.plate_style_bottom_text_color', plate_style_bottom_text_color);
                selectOptionsInSelect2('.plate_style_bottom_text_font', plate_style_bottom_text_font);
                selectOptionsInSelect2('.plate_style_bottom_text_size', plate_style_bottom_text_size);

            $(".add-plate-style").click();

        });
        
    });


        $(document).on('change input', '.new-input', function(){
        console.log($(this).val());
        $('#hidden-name').val($(this).val());
    });
    

    var clicks = 0;
    $('.add-prop').click(function () {
        clicks++;
        if (clicks >= 1 )
        {
        $(this).prop('disabled',true);
        clicks = 0;
        }
        let categoryTitle = $(this).closest('div').find('h2.category-title').text();
        const inputElement = $('<input  type="text" class="new-input">');
        const confirmButton = $('<button class="confirm-button btn btn-warning">Confirm</button>');
        const flexDiv = $(this).closest('div');
        const file = $('<input type="file" class="plate_customizer_font_file" name="plate_customizer_font_file">');
        if (categoryTitle == 'Plate Font') {

            form = '<form style="width:8% !important;" method="POST" id="plate_customizer_font_form" enctype="multipart/form-data" action=""><input type="file" style="color: transparent !important;" class="plate_customizer_font_file" name="plate_customizer_font_file"><input type="hidden" id="hidden-name" name="font-name"></form>';

            flexDiv.append('&nbsp;&nbsp;', form, inputElement, '&nbsp;', confirmButton, '<br>');
        }
        else {
            flexDiv.append('&nbsp;', inputElement, '&nbsp;', confirmButton, '<br>');
        }
        confirmButton.on('click', function () {
            
            categoryTitle = categoryTitle.toLowerCase().replace(/\s+/g, '_');
            const propValue = $(this).prev('.new-input').val();
            addPropertyValue(categoryTitle, propValue);
            $(this).prev('.new-input').remove();
            $(this).remove();
            if (file.length > 0) {
                file.remove();
                $('#plate_customizer_font_form').submit();
            }
        });
    });


    $('.plate_style_fonts').select2();
    $('.plate_style_border').select2();
    $('.plate_style_bottom_text_color').select2();
    $('.plate_style_bottom_text_font').select2();
    $('.plate_style_bottom_text_size').select2();
    $('.plate_style_badge_type').select2();
    $('.plate_style_badge_colors').select2();
    $('.plate_style_badge_images').select2();


$('.plate_style_badge_type').on('change', function() {
    var selectedOptions = $(this).val();
    var formattedSelectedOptions = selectedOptions.map(function(value) {
        return value.toLowerCase().replace(/\s+/g, '_');
    });
    var regexPattern = new RegExp(formattedSelectedOptions.join('|'), 'i');
    $('.plate_style_badge_images option').each(function(index, option) {
        var optionValue = $(option).val();
        var formattedOptionValue = optionValue.toLowerCase().replace(/\s+/g, '_');
        
        if (regexPattern.test(formattedOptionValue)) {
            $(option).prop('selected', true);
        }
    });
    $('.plate_style_badge_images').trigger('change');
});


    // ------------------------------------------------
    function addPropertyValue(property, value) {
        const data = {
            action: 'save_new_value',
            property: property,
            value: value,
            // processData: false,
            // contentType: false,
        };

        jQuery.post(plate_customizer_ajax.ajax_url, data, function (response) {
            if (response === 'success') {
                alert(value + ' Added Successfully.');
                window.location.reload();
            } else {
                alert('Failed to Add the value. Error: ' + response);
            }
        });
    }

    function removePropertyValue(property, value) {
        const data = {
            action: 'remove_value',
            property: property,
            value: value
        };

        jQuery.post(plate_customizer_ajax.ajax_url, data, function (response) {
            if (response === 'success') {
                alert(value + ' removed successfully.');
            } else {
                alert('Failed to remove the value. Error: ' + response);
            }
        });
    }

    // ---------------------------------------------------------

});

