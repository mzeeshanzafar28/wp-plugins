<?php
/*
Plugin Name: WhatsMate
Author: Axon Technologies
Description: WhatsMate is a plugin that allows you to  chat in whatsapp with your client directly from the Orders page.
Author URI: http://www.axonteam.pk
Version: 1.0.0
License: GPLv2 or Later
*/

defined('ABSPATH') or die('No script kiddies please!');

function add_whatsapp_chat_column_header($columns) {
    $columns['whatsapp_chat'] = 'WhatsApp Chat';
    return $columns;
}
add_filter('manage_edit-shop_order_columns', 'add_whatsapp_chat_column_header');

function add_whatsapp_chat_column_data($column, $post_id) {
    if ($column === 'whatsapp_chat') {
        $order = wc_get_order($post_id);
        $customer_phone = $order->get_billing_phone();

        if (!empty($customer_phone)) {
            $phone_number = preg_replace('/[^0-9]/', '', $customer_phone);

            if ($phone_number[0] == '0') {
                $formatted_phone = '+92' . ltrim($phone_number, '0');
            } else {
                $formatted_phone = $phone_number;
            }

            $whatsapp_url = "https://wa.me/{$formatted_phone}";

            echo '<a href="' . esc_url($whatsapp_url) . '" target="_blank">Chat on WhatsApp</a>';
        } else {
            echo 'N/A';
        }
    }
}
add_action('manage_shop_order_posts_custom_column', 'add_whatsapp_chat_column_data', 10, 2);
