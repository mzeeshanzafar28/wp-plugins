<?php
echo "Silence is golden.";
exit;