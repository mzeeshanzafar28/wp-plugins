jQuery(document).ready(function($) {
    console.log('Wave payment gateway initialized');
}); 