<?php

echo "No Script Kiddies !";