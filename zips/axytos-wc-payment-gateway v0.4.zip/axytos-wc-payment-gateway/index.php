<?php

_e('Access Denied.', 'axytos-wc');