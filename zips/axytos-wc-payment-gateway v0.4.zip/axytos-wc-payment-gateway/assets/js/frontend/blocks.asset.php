<?php return array('dependencies' => array('react', 'wp-html-entities'), 'version' => '370a7bff172964bfb70e');
