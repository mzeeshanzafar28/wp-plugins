import { decodeEntities } from '@wordpress/html-entities';

const { registerPaymentMethod } = window.wc.wcBlocksRegistry;
const { getSetting } = window.wc.wcSettings;

const settings = getSetting('axytoswc_data', {});

const label = decodeEntities(settings.title || 'Axytos');
const description = decodeEntities(settings.description || '');

const Content = () => <p>{description}</p>;

const Label = (props) => {
    const { PaymentMethodLabel } = props.components;
    return <PaymentMethodLabel text={label} />;
};

registerPaymentMethod({
    name: 'axytoswc',
    label: <Label />,
    content: <Content />,
    edit: <Content />,
    canMakePayment: () => true,
    ariaLabel: label,
    supports: {
        features: settings.supports || [],
    },
});


(function () {
    const { __experimentalRegisterCheckoutFilters } = wp.data;

    wp.domReady(() => {
        const body = document.body;

        const observer = new MutationObserver(() => {
            const errorMessage = body.querySelector('.is-error .wc-block-components-notice-banner__content div');

            if (errorMessage) {
                const checkoutContainer = document.querySelector('.wc-block-checkout');
                if (checkoutContainer) {
                    // document.location.reload();
                    wp.data.dispatch('wc/store').cartDataUpdated({ type: 'extensionCartUpdate' });

                }
            }
        });

        observer.observe(body, {
            childList: true,
            subtree: true,
        });
    });
})();

