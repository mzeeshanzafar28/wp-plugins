<?php
echo "You cannot be here";
?>