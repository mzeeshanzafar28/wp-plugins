<?php
echo 'silence is golden';